14.10.2008 16:04;GDE

NET-PnP-Service:



//-----------------------------------------------

Installation of the service:

Please be sure, that the camera driver is already installed!

Parameter of Argument  PollingTime in [msec]

Here you can adjust how often the plugged/unplugged event is
being polled.(Range: form 100 - 10000 msec)
If a wrong value is being set, the service will poll at 1000 msec.

After installation, you have to start the service or reboot.

//-----------------------------------------------

Running the service:

	Starting the service:
	The service polls the plugged/unplugged event
	of the usb-camera and initializes accordingly 
	the DShow-interface.

	Stopping the service:
	Is the service is stopped/closed, the DShow-interface is
	being initialized fix on "camera present".

//-----------------------------------------------

Deinstallation of the service:

Warning: Be sure that he camera is connected,
	 when you delete the service!

